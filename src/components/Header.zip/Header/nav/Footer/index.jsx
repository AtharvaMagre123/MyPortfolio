import styles from './style.module.scss';

export default function index() {
  return (
    <div className={styles.footer}>
        <a>Instagram</a>
        <a>Github</a>
        <a>LinkedIn</a>
    </div>
  )
}
